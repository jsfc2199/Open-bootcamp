"""
Usando for
"""

for i in range(100,0,-1):
    print("Este es el valor de i usando el bucle for ", i)

"""
Usando while
"""

x=100
while(x>0):
    print("Este es el valor de x usando el bucle while " , x)
    x-=1